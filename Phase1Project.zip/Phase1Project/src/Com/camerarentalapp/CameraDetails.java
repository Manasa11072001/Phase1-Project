package Com.camerarentalapp;

import java.util.ArrayList;
import java.util.Scanner;

public class CameraDetails {
	Scanner sc=new Scanner(System.in);
	private static double walletBalance = 1500;

	private static ArrayList<Camera> al = new ArrayList<>();

	public void CheckDetails(Scanner scanner)
	{
		System.out.println("+----------------------------+");
		System.out.println("|WELCOME TO CAMERA RENTAL APP|");
		System.out.println("+----------------------------+");
		System.out.println("PLEASE LOGIN TO CONTINUE-");
		System.out.println("username-");
		String username=sc.nextLine();
		System.out.println("password-");
		String password=sc.nextLine();
		if(username.equals("admin")&&password.equals("admin123"))
		{
			System.out.println("Login successfull");
			cameraList();
			displayOptions(scanner);

		}
		else
		{
			System.out.println("Authentication failed");
		}

	}
	private void cameraList() {
		// TODO Auto-generated method stub
		al.add(new Camera(11, "Samsung", "SM123", 1400, true));
		al.add(new Camera(12, "Nikon", "DSLR", 1600, true));
		al.add(new Camera(13, "Sony", "Sony12", 1300, true));
		al.add(new Camera(14, "Canon", "XPL", 1800, true));
		al.add(new Camera(18, "Chroma", "HD12", 1100, true));
		al.add(new Camera(19, "NIKON", "DIGITAL", 2500, true));
		al.add(new Camera(15, "Panasonic", "MP-11-AP", 1750, true));
		al.add(new Camera(16, "Fujitsu", "V12-PL",2000, true));
		al.add(new Camera(17, "CANON", "LK-LV",1500, true));
	}


	private void displayOptions(Scanner scanner) {
		int choice;
		do {
			System.out.println("1. Manage My Cameras");
			System.out.println("2. Rent a Camera");
			System.out.println("3. View All Cameras");
			System.out.println("4. Manage My Wallet");
			System.out.println("5. Exit");
			System.out.print("Select an option: ");
			choice = scanner.nextInt();
			switch (choice) {
			case 1:
				manageMyCameras(scanner);
				break;
			case 2:
				rentCamera(scanner);
				break;
			case 3:
				viewAllCameras();
				break;
			case 4:
				manageWallet(scanner);
				break;
			case 5:
				return;
			default:
				System.out.println("Invalid choice. Please select a valid option.");
			}
		} while (true);
	}
	private static void manageMyCameras(Scanner scanner) {
		int choice;
		do {
			System.out.println("1. Add Camera");
			System.out.println("2. Remove Camera");
			System.out.println("3. View My Cameras");
			System.out.println("4. Go to Previous Menu");
			System.out.print("Enter your choice: ");
			choice = scanner.nextInt();
			switch (choice) {
			case 1:
				System.out.print("Enter Camera ID: ");
				int cameraId = scanner.nextInt();
				System.out.print("Enter Camera Brand: ");
				String brand = scanner.next();
				System.out.print("Enter Camera Model: ");
				String model = scanner.next();
				System.out.print("Enter Camera Price per day: ");
				double price = scanner.nextDouble();
				boolean isAvailable = true;
				al.add(new Camera(cameraId, brand, model, price, isAvailable));
				System.out.println("Camera successfully added.");
				break;
			case 2:
				System.out.print("Enter Camera ID to remove: ");
				int removeId = scanner.nextInt();
				boolean isRemoved = false;
				for (Camera camera : al) {
					if (camera.getId() == removeId) {
						al.remove(camera);
						isRemoved = true;
						break;
					}
				}
				if (isRemoved) {
					System.out.println("Camera successfully removed.");
				} else {
					System.out.println("Camera not found with given ID.");
				}
				break;
			case 3:
				System.out.println("My Cameras:");
				System.out.println("-------------------------------------------------------------------------------------");
				System.out.printf("| %-10s | %-15s | %-15s | %-10s | %-10s |%n",
						"Camera ID", "Brand", "Model", "Price", "Availability");
				System.out.println("---------------------------------------------------------------------------------------");
				for (Camera camera : al) {
					if (!camera.isAvailable()) {
						System.out.format("| %-10d | %-15s | %-15s | %-10.2f | %-10s |%n",
								camera.getId(), camera.getBrand(), camera.getModel(), camera.getPrice_perday(),
								camera.isAvailable() ? "Available" : "Rented");
					}
				}
				System.out.println("-----------------------------------------------------------------------------");

				break;
			case 4:
				return;
			default:
				System.out.println("Invalid choice. Please select a valid option.");
			}
		} while (true);
	}

	private static void rentCamera(Scanner scanner) {
		System.out.println("Available Cameras for Rent:");
		for (Camera camera : al) {
			if (camera.isAvailable()) {
				System.out.println("Camera ID: " + camera.getId() + ", Brand: " + camera.getBrand() +
						", Model: " + camera.getModel() + ", Price: " + camera.getPrice_perday());
			}
		}
		System.out.print("Enter the Camera ID you want to rent: ");
		int rentId = scanner.nextInt();
		boolean isFound = false;
		for (Camera camera : al) {
			if (camera.getId() == rentId && camera.isAvailable()) {
				if (walletBalance >= camera.getPrice_perday()) {
					camera.setAvailable(false);
					walletBalance -= camera.getPrice_perday();
					System.out.println("Camera rented successfully. Your current wallet balance: " + walletBalance);
				} else {
					System.out.println("You don't have sufficient balance in your wallet to rent this camera.");
				}
				isFound = true;
				break;
			}
		}
		if (!isFound) {
			System.out.println("Camera not available for rent with the given ID.");
		}
	}

	private static void viewAllCameras() {
		System.out.println("List of all available cameras:");
		System.out.println("----------------------------------------------------------------------------");
		System.out.printf("| %-10s | %-15s | %-15s | %-10s | %-10s |%n",
				"Camera ID", "Brand", "Model", "Price", "Availability");
		System.out.println("----------------------------------------------------------------------------");
		for (Camera camera : al) {
			System.out.format("| %-10d | %-15s | %-15s | %-10.2f | %-10s |%n",
					camera.getId(), camera.getBrand(), camera.getModel(), camera.getPrice_perday(),
					camera.isAvailable() ? "Available" : "Rented");
		}
		System.out.println("----------------------------------------------------------------------------");
	}

	private static void manageWallet(Scanner scanner) {
		System.out.println("Your current wallet balance is: " + walletBalance);
		System.out.print("Do you want to deposit more amount to your wallet? (1. Yes 2. No): ");
		int choice = scanner.nextInt();
		if (choice == 1) {
			System.out.print("Enter deposit amount: ");
			double addAmount = scanner.nextDouble();
			walletBalance += addAmount;
			System.out.println("Your wallet balance has been updated successfully. Current balance: " + walletBalance);
		}


	}

}
