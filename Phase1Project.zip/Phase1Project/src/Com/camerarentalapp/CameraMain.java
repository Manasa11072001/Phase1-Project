package Com.camerarentalapp;

import java.util.Scanner;

public class CameraMain {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
        CameraDetails cd=new CameraDetails();
        cd.CheckDetails(scanner);
		
		
	}
	
}
